#include <stdio.h>
#include <conio.h>
int main()
{
int i;
clrscr();
for(i=0;i<255;i++){
printf("%c ASCII Tablosundaki kar��l���=%d \n",i,i);
if((i % 22) == 0 ){
getch();
clrscr();
}
}
return 0;}
